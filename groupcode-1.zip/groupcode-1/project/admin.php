<html>

<head>
    <title>
        searching
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>Hamaray bachay</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
                login as admin
            </h1>
        </div>
    </nav>
	
	<div class="signinform">
        <div class="signupheading">
            <h1>
                Enter username and password
            </h1>
        </div>

        <div class="signinformdata">

            <form  method= "post">
				
                <h3>User name</h3>
                <input type="text" id="rname" name="username" placeholder="user name Here" size="40">
				<br>
				<br>
				<h3>password</h3>
                <input type="password" id="rpass" name="pass" placeholder="*****" size="40">
				<br>
                <br><br>
               
				<br>
                <br>
                <br>
                <button type="submit" name="submit" > Submit</button>
            </form>
            <?php
//session_start();
if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";

   $nam=$_POST['username'];
   $pass=$_POST['pass'];
   
    


$checkvalid=false;

$sql=" select NAME from admin where NAME='$nam' and PASS='$pass';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
   $checkvalid=true;
   
}
if($checkvalid==true){
    
    header('Location:adminviewpage.php');
    echo"true";
  
}
else{
    echo"entered wrong id and password ";
    echo"<br>";
    header('Location:admin.php');

}

      
      mysqli_close($con);
   
  }
  else{
    echo "not success";
  }
}


            ?>
            

        </div>
    </div>

    
    <div class="signindesign1">

        <div class="signindesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMRAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signinclick1">
                <button>
					     <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
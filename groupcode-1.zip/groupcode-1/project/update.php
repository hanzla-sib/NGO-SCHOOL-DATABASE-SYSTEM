<html>

<head>
    <title>
        UPDATE INFO
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
                UPDATE INFORMATION
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
                Enter your Details to update
            </h1>

            <h4>enter the student's father cnic and stduent name whose data you want to edit</h4>
            <div class="signupformdata">
            <form method="post">
            <h3>Name</h3>
                <input type="text" id="name" name="name" placeholder="Name here" size="40" >
				<br>
				<br>
                <h3>father cnic</h3>
                <input type="text" id="fathercnic" name="cnicfather" placeholder="36302-67694737">
                <br>
				<br>
                <h2 style="text-align: center;">now enter the data to update</h2>
                <h3>Name</h3>
                <input type="text" id="uname" name="updatedname" placeholder="Name here" size="40" >
				<br>
				<br>
                <h3>gender</h3>
                <input type="radio" name="gender" value="male"> Male<br>
                <input type="radio" name="gender" value="female"> Female<br>
				<br>
				<br>
                <h3>date of birth</h3>
                <input type="date" id="birthday" name="birthday">
                <br>
				<br>
                <h3>Father Name</h3>
                <input type="text" id="fathername" name="fathername" placeholder="Name here" size="40" >
				<br>
				<br>
                <h3>father cnic</h3>
                <input type="text" id="fathercnic" name="updatedcnicfather" placeholder="36302-67694737">
                <br>
				<br>
                <h3>father Job</h3>
                <input type="text" id="fatherjob" name="job" placeholder="enginear">
                <br>
				<br>
                <h3>mothername</h3>
                <input type="text" id="mothername" name="mothername" placeholder="Name here" size="40" >
				<br>
				<br>
                
                <h3>CNIC MOTHER</h3>
                <input type="text" id="cnicname" name="cnicmother"placeholder="36302-67694737" size="40">
                <br>
				<br>
                
                <h3>in case of any emergency type below and in case of no emergency type none </h3>
                <input type="text" id="emergency" name="emergency" size="40">
                <br>
				<br>

                <h3> father phone no</h3>
                <input type="tel" id="fphone" name="fphone" placeholder="123-45-678">
                <br><br>
                <h3> mother phone no</h3>
                <input type="tel" id="mphone" name="mphone" placeholder="123-45-678">
                <br><br>
                <h3>ADDRESS</h3>
                <input type="text" id="address" name="address" placeholder="address">
                <br><br>
                <hr>
                
                <button type="submit" name="submit" > Submit</button>
            </form>
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess";
    $nam=$_POST['name'];
   $fatcnic=$_POST['cnicfather'];
   $updatednam=$_POST['updatedname'];
    $gend=$_POST['gender'];
    $dobbirth=$_POST['birthday'];
    $fname=$_POST['fathername'];
    $updatedfatcnic=$_POST['updatedcnicfather'];
    $mname=$_POST['mothername'];
    $motcnic=$_POST['cnicmother'];
    $fathernumber=$_POST['fphone'];
    $mothernumber=$_POST['mphone'];
    $addressparents=$_POST['address'];
    // $guarrelation=$_POST['guardianreletion'];
    // $gname=$_POST['guardianname'];
    // $guardcnic=$_POST['cnicguardian'];
    // $guardaddress=$_POST['guardianaddress'];
    // $guardiannumber=$_POST['guardianphone'];
    $emergency=$_POST['emergency'];
    $job=$_POST['job'];


$checkexist=false;
$guardian=null;
$sql=" select gcnic from student where NAME='$nam' and fcnic='$fatcnic';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
   $guardian=$row["gcnic"];
   
}
echo"guardian cnic ="."$guardian";
echo"<hr>";
      $sql=" select * from student where NAME='$nam' and fcnic='$fatcnic';";
      
      $result = mysqli_query($con, $sql);
    
      $count=0;
      while($row=mysqli_fetch_assoc($result))
      {
         $checkexist=true;
         
      }
      $sql=" select * from student where fcnic='$fatcnic';";
      $result = mysqli_query($con, $sql);
    
     
      while($row=mysqli_fetch_assoc($result))
      {
         $count++;
         
      }
      $today = date("Y-m-d");
      $diff = date_diff(date_create($dobbirth), date_create($today));
    
      $age=$diff->format('%y');
      if($checkexist==true){
          if($count==1){
            $sql="update student set NAME='$updatednam',dob='$dobbirth',age='$age',gender='$gend',fcnic='$updatedfatcnic' where NAME='$nam'and fcnic='$fatcnic';";
            if ($con->query($sql) === TRUE) {
              echo "Record updated successfully in student";
            } else {
              echo "Error updating record: " . $con->error;
            }
            $sql=" select fathercnic from parents where fathercnic='$fatcnic';";
            $result = mysqli_query($con, $sql);
    
            $checkcnicfather=false;
            while($row=mysqli_fetch_assoc($result))
           {
            $checkcnicfather=true;
         
           }
           if($checkcnicfather==true){
            $sql="update parents set fathername='$fname',fathercnic='$updatedfatcnic',mothername='$mname',mothercnic='$motcnic',fathernumber='$fathernumber',mothernumber='$mothernumber',address='$addressparents',job='$job',anyemergency='$emergency' where fathercnic='$fatcnic';";
            if ($con->query($sql) === TRUE) {
              echo "Record updated successfully in parent";
            } else {
              echo "Error updating record: " . $con->error;
            }
           }
           else{
            $sql="insert into parents(fathername,fathercnic,mothername,mothercnic,fathernumber,mothernumber,address,job,anyemergency) values('$fname','$updatedfatcnic','$mname','$motcnic','$fathernumber','$mothernumber','$addressparents','$job','$emergency')";
            if ($con->query($sql) === TRUE) {
              echo "Record updated successfully in parent";
            } else {
              echo "Error updating record: " . $con->error;
            }
           }
            
          }
          else{
            $sql=" select fathercnic from parents where fathercnic='$fatcnic';";
            $result = mysqli_query($con, $sql);
    
            $checkcnicfather=false;
            while($row=mysqli_fetch_assoc($result))
           {
            $checkcnicfather=true;
         
           }
           if($checkcnicfather==true){
            $sql="update student set NAME='$updatednam',dob='$dobbirth',age='$age',gender='$gend',fcnic='$updatedfatcnic' where NAME='$nam'and fcnic='$fatcnic';";
            if ($con->query($sql) === TRUE) {
              echo "Record updated successfully in student";
            } else {
              echo "Error updating record: " . $con->error;
            }
            $sql=" select fathercnic from parents where fathercnic='$fatcnic';";
            $result = mysqli_query($con, $sql);
    
            $checkcnic=NULL;
            while($row=mysqli_fetch_assoc($result))
           {
            $checkcnic=$row['fathercnic'];
         
           }
            if($updatedfatcnic==$checkcnic){
                $sql="update parents set fathername='$fname',fathercnic='$updatedfatcnic',mothername='$mname',mothercnic='$motcnic',fathernumber='$fathernumber',mothernumber='$mothernumber',address='$addressparents',job='$job',anyemergency='$emergency' where fathercnic='$fatcnic';";
                if ($con->query($sql) === TRUE) {
                  echo "Record updated successfully in parent";
                } else {
                  echo "Error updating record: " . $con->error;
                }
            }
           }
           else{
                $sql="insert into parents(fathername,fathercnic,mothername,mothercnic,fathernumber,mothernumber,address,job,anyemergency) values('$fname','$updatedfatcnic','$mname','$motcnic','$fathernumber','$mothernumber','$addressparents','$job','$emergency')";
                if ($con->query($sql) === TRUE) {
                  echo "Record updated successfully in parent";
                } else {
                  echo "Error updating record: " . $con->error;
                }
            }
           
          }
         

      }
      else{
          echo"record not found against this child<br>";
      }
   
      // Free result set
      mysqli_close($con);
   
  }
  else{
    echo "not success";
  }
}


?>
            </div>



        </div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
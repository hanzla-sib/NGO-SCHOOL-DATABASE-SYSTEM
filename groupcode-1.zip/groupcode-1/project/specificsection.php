<html>

<head>
    <title>
       specific section data
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
               
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
            specific section data
            </h1>
            <form method="post">
            <h3>section name</h3>
                <input type="text" id="secname" name="secname" placeholder="name Here" size="40">
				<br>
                <br>
                <br>
                <button type="submit" name="submit" > Submit</button>




            </form>
           
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";
    
    $sec=$_POST['secname'];
    $sql=" select sectionname,counting from section where sectionname='$sec' order by sectionname;";
    $result1 = mysqli_query($con, $sql);
    while($row=mysqli_fetch_assoc($result1))
    {
        echo "       sectionname =  ". $row["sectionname"];
        echo "   | |     total students =  ". $row["counting"];
        
      
      
       echo"<hr>";
       
       
    }
    

      
      mysqli_close($con);
   
  }
  else{
      mysqli_error($con);
  }
 
}


            ?>
            </div>



        </div>
        <div class="signupdesign1">

<div class="signupdesign-data1">
    <h1>
       click on button u want to proceed.
    </h1>
   
    <div class="signupclick1">
        <button>
                     <a href="specificsection.php">show specific section</a>
        </button>
       
    </div>
</div>
</div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
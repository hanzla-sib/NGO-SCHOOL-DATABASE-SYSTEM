<html>

<head>
    <title>
    check fee status
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>Hamaray bachay</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
                 

            </div>


        </div>
        <div id="abttext3">
            <h1>
                pay fee chalan
            </h1>
        </div>
    </nav>
	
	<div class="signinform">
        <div class="signupheading">
            <h1>
                Enter your Details
            </h1>
        </div>

        <div class="signinformdata">

            <form  method= "post">
				
                <h3>name</h3>
                <input type="text" id="naming" name="naming" placeholder="name Here" size="40">
				<br>
				<br>
				<h3>father cnic</h3>
                <input type="text" id="rcnic" name="rcnic" placeholder="36302-67694737" size="40">
				<br>
                <br><br>
                <h3>pay fee</h3>
                <input type="checkbox" name="check"  size="40"> 
				<br>
                <br><br>
				<br>
                <br>
                <br>
                <button type="submit" name="submit" > Submit</button>
            </form>
            

        </div>
    </div>

    <div>
     <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";

   $nam=$_POST['naming'];
   $fatcnic=$_POST['rcnic'];
   $check=$_POST['check'];
   
    


$checkcnic=false;

$sql=" select gcnic from student where NAME='$nam' and fcnic='$fatcnic';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
   $checkcnic=true;
   
}
if($checkcnic==true){
    $feestatus=NULL;
  $sql=" select NAME,gender,fcnic,fee,coursename,classname,coursesection from student where NAME='$nam' and fcnic='$fatcnic';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
   $feestatus=$row['fee'];
   if($feestatus=='unpaid'){
    $sql="update student set fee='paid' where NAME='$nam' and fcnic='$fatcnic';";
   
    if ($con->query($sql) === TRUE) {
        echo "fee status updated successfully in student";
       
      } else {
        echo "Error updating fee registartion: " . $con->error;
      }
   }
   else{
    echo"fee is already paid<br>";
   }

   
}


}
else{
    echo"record not found";
    echo"<br>";
}

      
      mysqli_close($con);
   
  }
  else{
    echo "not success";
  }
}


            ?> 


    </div>
    <div class="signindesign1">

        <div class="signindesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMRAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signinclick1">
                <button>
					     <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
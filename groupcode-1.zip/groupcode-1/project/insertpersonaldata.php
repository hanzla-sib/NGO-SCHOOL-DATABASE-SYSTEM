<!DOCTYPE html>
<html>

<head>
    <title>
       inserted
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar1">
            <div id="logo1">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars1">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
       
    </nav>

    <div class="midsection">
        <div class="text-pic">
            <div class="textside" style="text-align: center;" >
            <?php

if(isset($_POST['submit'])){
  
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";
    echo"<br>";
    $nam=$_POST['name'];
    $gend=$_POST['gender'];
    $dobbirth=$_POST['birthday'];
    $fname=$_POST['fathername'];
    $fatcnic=$_POST['cnicfather'];
    $mname=$_POST['mothername'];
    $motcnic=$_POST['cnicmother'];
    $fathernumber=$_POST['fphone'];
    $mothernumber=$_POST['mphone'];
    $addressparents=$_POST['address'];
    $guarrelation=$_POST['guardianreletion'];
    $gname=$_POST['guardianname'];
    $emergency=$_POST['emergency'];
    $guardcnic=$_POST['cnicguardian'];
    $guardaddress=$_POST['guardianaddress'];
    $guardiannumber=$_POST['guardianphone'];
    $job=$_POST['job'];


#for checking the parent
$checkparent=false;
$count=0;
$sql=" select * from student where NAME='$nam' and fcnic='$fatcnic'";
      $result = mysqli_query($con, $sql);
      while($row=mysqli_fetch_assoc($result))
      {
         $count++;
         
         
      }
      if($count<1){
        $sql=" select * from parents where fathercnic='$fatcnic'";
        $result = mysqli_query($con, $sql);
        while($row=mysqli_fetch_assoc($result))
        {
            $checkparent=true;
           
           
        }
        $checkguardian=false;
        $sql=" select * from guardian where guardiancnic='$guardcnic'";
              $result = mysqli_query($con, $sql);
              while($row=mysqli_fetch_assoc($result))
              {
                  $checkguardian=true;
                 
                 
              }
   
              $today = date("Y-m-d");
              $diff = date_diff(date_create($dobbirth), date_create($today));
            
              $age=$diff->format('%y.%m');
              echo"$age<hr>";
              if($age<=15 && $age>=3){
                $roll=(rand(100000,200000));
                  $sql = "insert into student (NAME, dob,age,gender,fcnic,gcnic,rollnumber)
                  VALUES ('$nam','$dobbirth','$age','$gend','$fatcnic','$guardcnic','$roll')";
                  
                  if ($con->query($sql) === TRUE) {
                    echo "New record created successfully in student";
                  } else {
                    echo "Error: " . $sql . "<br>" . $con->error;
                  }
                  
                  if($checkparent==false){ # cehckl for parent existing
                    $sql = "insert into parents (fathername , fathercnic ,mothername ,mothercnic ,fathernumber ,mothernumber ,address,job,anyemergency )
                    VALUES ('$fname','$fatcnic','$mname','$motcnic','$fathernumber','$mothernumber','$addressparents','$job','$emergency')";
                    
                    if ($con->query($sql) === TRUE) {
                      echo "New record created successfully in parent";
                    } else {
                      echo "Error: " . $sql . "<br>" . $con->error;
                    }
                  }
                  
                  if($checkguardian==false){
                    $sql = "insert into guardian (guardianreletion , guardianname ,guardiancnic ,guardianaddress ,guardianphone  )
                    VALUES ('$guarrelation','$gname','$guardcnic','$guardaddress','$guardiannumber')";
                    
                    if ($con->query($sql) === TRUE) {
                      echo "New record created successfully in guardian";
                    } else {
                      echo "Error: " . $sql . "<br>" . $con->error;
                    }
                  }
               
                 
                }
                else{
                  echo "you are not eligible for this school<br>";
                  if($age>15){
                    echo "you are over 15 years old<br>";
                  }
                  else if($age<3){
                    echo "you are less then 3 years old<br>";
                  }
                 
                  echo"<br>";
                  echo"for signing up again click the button below";
                }


      }
      else{
        echo"already registered<br>";
      }

           
    

$con->close();
    
  }
  else{
    echo "not success";
  }
}


?>

            </div>

        </div>
      

    

    <div class="finalservice">
       
        <br><br>
      
    </div>

    <div class="design2">

        <div class="design-data2">
            <h1>
                if you want to sign up for other child click below button
            </h1>
            <p>
               SIGN up and enter your details.

            </p>

            <div class="click2">
                <button>
                    <a href="signup.html">Sign up</a>
                </button>
            </div>
        </div>
    </div>

    <div class="follow">
        <div class="follow-data">
            <h1>Follow Us On</h1><br>

            <div class="ic">
                <i class="fab fa-twitter"></i>
                <i class="fab fa-youtube"></i>
                <i class="fab fa-snapchat-ghost"></i>
            </div>


        </div>
    </div>
    

</body>

</html>
<html>

<head>
    <title>
      class assignment form
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
               
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
            assign a student new class
            </h1>
            <form method="post">
            <h3>rollnumber</h3>
                <input type="text" id="name" name="rollnum" placeholder="190515" size="40">
				<br>
                <br>
                <h3>current class</h3>
                <input type="text" id="name" name="curclass" placeholder="1" size="40">
                <br>
                <h3>new class</h3>
                <input type="text" id="name" name="newclass" placeholder="2" size="40">
                <br>
                <h3>Reason for change</h3>
                <input type="text" id="name" name="reason" placeholder="" size="40">
                <br>
                <br>
                <h3>Approved by</h3>
                <input type="text" id="name" name="approve" placeholder="" size="40">
                <br>
                <br>
                <br>
                <button type="submit" name="submit" > Submit</button>
                <br>
                <hr><br><br><br>



            </form>
           
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";
    
    $roll=$_POST['rollnum'];
    $currentclass=$_POST['curclass'];
    $newclass=$_POST['newclass'];
    $reason=$_POST['reason'];
    $sql=" select rollnumber,classname,age,gender,coursesection from student where rollnumber='$roll';";
    $result1 = mysqli_query($con, $sql);
    $checkroll=false;
    $oclass=0;
    $approve=$_POST['approve'];
    $section=array();
    $coursesection=NULL;

    while($row=mysqli_fetch_assoc($result1)){
    $checkroll=true;
    $oclass=$row['classname'];
    $coursesection=$row['coursesection'];
       
    }
    $length=strlen($coursesection);
    $dec=2;
    $length=$length-$dec;
    
   
    if($checkroll==true){
        if($oclass==$currentclass){
            if($newclass==1){
                $sql=" update student set classname ='$newclass' where rollnumber='$roll'";
                if ($con->query($sql) === TRUE) {
                    echo "Record updated successfully";
                  } else {
                    echo "Error updating record: " . $con->error;
                  }
                if($coursesection[0]=='E'){
                    $sql=" update student set coursename ='English' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='English-1-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-1-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='English-1-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-1-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }

                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='M'){
                    $sql=" update student set coursename ='Math' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Math-1-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-1-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Math-1-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-1-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='U'){
                    $sql=" update student set coursename ='Urdu' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Urdu-1-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-1-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Urdu-1-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-1-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='S'){
                    $sql=" update student set coursename ='Science' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Science-1-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-1-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Science-1-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-1-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                $sql=" insert into historyofclass (rollnumber,oldclassname,newclassname,reasonforchange,approvedby) values('$roll','$oclass','$newclass','$reason','$approve')";
                
                if ($con->query($sql) === TRUE){
                    echo "Record updated successfully";
                }
            }
            else if($newclass==2){
                $sql=" update student set classname ='$newclass' where rollnumber='$roll'";
                if ($con->query($sql) === TRUE) {
                    echo "Record updated successfully";
                  } else {
                    echo "Error updating record: " . $con->error;
                  }
                if($coursesection[0]=='E'){
                    $sql=" update student set coursename ='English' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='English-2-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-2-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='English-2-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-2-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }

                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='M'){
                    $sql=" update student set coursename ='Math' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Math-2-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-2-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Math-2-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-2-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='U'){
                   
                    $sql=" update student set coursename ='Urdu' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                           
                            $sql=" update student set coursesection ='Urdu-2-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                               
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-2-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Urdu-2-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-2-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='S'){
                    $sql=" update student set coursename ='Science' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Science-2-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-2-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Science-2-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-2-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                $sql=" insert into historyofclass (rollnumber,oldclassname,newclassname,reasonforchange,approvedby) values('$roll','$oclass','$newclass','$reason','$approve')";
                
                if ($con->query($sql) === TRUE){
                    echo "Record updated successfully";
                }
            }
            else if($newclass==3){
                $sql=" update student set classname ='$newclass' where rollnumber='$roll'";
                if ($con->query($sql) === TRUE) {
                    echo "Record updated successfully";
                  } else {
                    echo "Error updating record: " . $con->error;
                  }
                if($coursesection[0]=='E'){
                    $sql=" update student set coursename ='English' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='English-3-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-3-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='English-3-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-3-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }

                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='M'){
                    $sql=" update student set coursename ='Math' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Math-3-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-3-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Math-3-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-3-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='U'){
                    $sql=" update student set coursename ='Urdu' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Urdu-3-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-3-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Urdu-3-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-3-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='S'){
                    $sql=" update student set coursename ='Science' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Science-3-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-3-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Science-3-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-3-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                $sql=" insert into historyofclass (rollnumber,oldclassname,newclassname,reasonforchange,approvedby) values('$roll','$oclass','$newclass','$reason','$approve')";
               
                if ($con->query($sql) === TRUE){
                    echo "Record updated successfully";
                }
            }
            else if($newclass==4){
                $sql=" update student set classname ='$newclass' where rollnumber='$roll'";
                if ($con->query($sql) === TRUE) {
                    echo "Record updated successfully";
                  } else {
                    echo "Error updating record: " . $con->error;
                  }
                if($coursesection[0]=='E'){
                    $sql=" update student set coursename ='English' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='English-4-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-4-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='English-4-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-4-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }

                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='M'){
                    $sql=" update student set coursename ='Math' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Math-4-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-4-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Math-4-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-4-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='U'){
                    $sql=" update student set coursename ='Urdu' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Urdu-4-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-4-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Urdu-4-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-4-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='S'){
                    $sql=" update student set coursename ='Science' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Science-4-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-4-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Science-4-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-4-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                $sql=" insert into historyofclass (rollnumber,oldclassname,newclassname,reasonforchange,approvedby) values('$roll','$oclass','$newclass','$reason','$approve')";
                
                if ($con->query($sql) === TRUE){
                    echo "Record updated successfully";
                }
            }
            else if($newclass==5){
                $sql=" update student set classname ='$newclass' where rollnumber='$roll'";
                if ($con->query($sql) === TRUE) {
                    echo "Record updated successfully";
                  } else {
                    echo "Error updating record: " . $con->error;
                  }
                if($coursesection[0]=='E'){
                    $sql=" update student set coursename ='English' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='English-5-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-5-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='English-5-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='English-5-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }

                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='M'){
                    $sql=" update student set coursename ='Math' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Math-5-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-5-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Math-5-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Math-5-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='U'){
                    $sql=" update student set coursename ='Urdu' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Urdu-5-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-5-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Urdu-5-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Urdu-5-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                else if($coursesection[0]=='S'){
                    $sql=" update student set coursename ='Science' where rollnumber='$roll'";
                    if ($con->query($sql) === TRUE) {
                        echo "Record updated successfully";
                        if($coursesection[$length]=='M'){
                            $sql=" update student set coursesection ='Science-5-(M)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-5-(M)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                        else if($coursesection[$length]=='F'){
                            $sql=" update student set coursesection ='Science-5-(F)' where rollnumber='$roll'";
                            if ($con->query($sql) === TRUE){
                                echo "Record updated successfully";
                                $sql=" update section set `counting`=counting+1 where sectionname ='Science-5-(F)' ";
               
                                if ($con->query($sql) === TRUE){
                                    echo "Record updated successfully";
                                }
                            }
                        }
                      } else {
                        echo "Error updating record: " . $con->error;
                      }
                }
                $sql=" insert into historyofclass (rollnumber,oldclassname,newclassname,reasonforchange,approvedby) values('$roll','$oclass','$newclass','$reason','$approve')";
               
                if ($con->query($sql) === TRUE){
                    echo "Record updated successfully";
                }
            }
            $sql=" update section set `counting`=counting-1 where sectionname ='$coursesection' ";
               
            if ($con->query($sql) === TRUE){
                echo "Record updated successfully";
            }
        }
        else{
            echo"student not registered in class $oclass<br>";
           
        }
    }
    else{
        echo"student not found with this rollnumber<br>";
    }
      mysqli_close($con);
   
  }
  else{
      mysqli_error($con);
  }
 
}
    ?>
            </div>



        </div>
        <div class="signupdesign1">

<div class="signupdesign-data1">
    <h1>
      
    </h1>
   
    <div class="signupclick1">
       
    </div>
</div>
</div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
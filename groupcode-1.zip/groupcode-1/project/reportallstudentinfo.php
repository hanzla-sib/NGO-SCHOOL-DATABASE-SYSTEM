<html>

<head>
    <title>
      all info of student
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
               
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
            student deatils
            </h1>
            <form method="post">
            <h3>name</h3>
                <input type="text" id="name" name="name" placeholder="name Here" size="40">
				<br>
                <br>
                <h3>rollnumber</h3>
                <input type="text" id="name" name="rollnumber" placeholder="190515" size="40">
                <br>
                <button type="submit" name="submit" > Submit</button>
                <br>
                <hr><br><br><br>



            </form>
           
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";
    
    $name=$_POST['name'];
    $roll=$_POST['rollnumber'];
    $sql=" select NAME,rollnumber,fcnic,gcnic,coursename,classname,coursesection from student where name='$name' and  rollnumber='$roll';";
    $result1 = mysqli_query($con, $sql);
    $checkbool=false;
    while($row=mysqli_fetch_assoc($result1))
    {   $checkbool=true;
        echo"<b>student details</b>";
        echo"<br>";
       
        $rollnumber=$row['rollnumber'];
        $nam=$row['NAME'];
        $fathercnic=$row['fcnic'];
        $gcnic=$row['gcnic'];
        $coursename=$row['coursename'];
        $classname=$row['classname'];
        $coursesection=$row['coursesection'];

         echo "       rollnumber =  ". $row['rollnumber'];
         echo"<br>";
        echo "       NAME =  ". $row['NAME'];
       
        echo"<br>";
        echo "        fathercnic =  ". $row['fcnic'];
        echo"<br>";
        echo "       guardian cnic =  ". $row['gcnic'];
        echo"<br>";
        echo "        course =  ". $row['coursename'];
        echo"<br>";
        echo "        class =  ". $row['classname'];
        echo"<br>";
        echo "       section =  ". $row['coursesection'];
        echo"<br>";
      
      
       echo"<hr>";
    }
    if($checkbool==true){
        $sql=" select fathername,mothername,mothercnic,fathernumber,mothernumber,address,job,anyemergency from parents where fathercnic='$fathercnic';";
        $result1 = mysqli_query($con, $sql);
        while($row=mysqli_fetch_assoc($result1))
        {
            // echo "       sectionname =  ". $row["sectionname"];
            // echo "   | |     total students =  ". $row["counting"];
            $fathername=$row['fathername'];
            $mothername=$row['mothername'];
            $mothercnic=$row['mothercnic'];
            $fathernumber=$row['fathernumber'];
            $mothernumber=$row['mothernumber'];
            $address=$row['address'];
            $job=$row['job'];
        echo"<b>parents details</b>";
        echo"<br>";
        echo "       fathername =  ". $row['fathername'];
        echo"<br>";
        echo "       mothername =  ". $row['mothername'];
        echo"<br>";
        echo "       mothercnic =  ". $row['mothercnic'];
        echo"<br>";
        echo "        fathernumber =  ". $row['fathernumber'];
        echo"<br>";
        echo "       mothernumber =  ". $row['mothernumber'];
        echo"<br>";
        echo "      address =  ". $row['address'];
        echo"<br>";
        echo "       job =  ". $row['job'];
        echo"<br>";
        echo"<hr>";
    
        }
    
        $sql=" select guardianname,guardiancnic,guardianreletion,guardianaddress,guardianphone from guardian where guardiancnic='$gcnic';";
        $result1 = mysqli_query($con, $sql);
        while($row=mysqli_fetch_assoc($result1))
        {
            // echo "       sectionname =  ". $row["sectionname"];
            // echo "   | |     total students =  ". $row["counting"];
            $guardianname=$row['guardianname'];
            $guardiancnic=$row['guardiancnic'];
            $guardianreletion=$row['guardianreletion'];
            $guardianaddress=$row['guardianaddress'];
            $guardianphone=$row['guardianphone'];
            
        //    echo"<hr>";
        echo"<b>guardian details</b>";
        echo"<br>";
        echo "       guardianname =  ". $row['guardianname'];
        echo"<br>";
        echo "      guardiancnic =  ". $row['guardiancnic'];
        echo"<br>";
        echo "       guardianreletion =  ". $row['guardianreletion'];
        echo"<br>";
        echo "        guardianaddress =  ". $row['guardianaddress'];
        echo"<br>";
        echo "        guardianphone =  ". $row['guardianphone'];
        echo"<br>";
       
        echo"<hr>";
    
        }
    
        $sql=" select NAME,rollnumber,fcnic,gcnic,coursename,classname,coursesection from student where fcnic='$fathercnic';";
        $result1 = mysqli_query($con, $sql);
        $i=0;
        $checksibling=false;
        echo"<b>sibling  details</b><br>";
        while($row=mysqli_fetch_assoc($result1))
        {
            
            // echo "       sectionname =  ". $row["sectionname"];
            // echo "   | |     total students =  ". $row["counting"];
            if($row['rollnumber']!=$roll){
                $checksibling=true;
                $i++;
     //    echo"<hr>";
     echo"<br>";
     echo"<b>sibling number $i details</b>";
     echo"<br>";
     echo "       Name =  ". $row['NAME'];
     echo"<br>";
     echo "      rollnumber =  ". $row['rollnumber'];
     echo"<br>";
     echo "       classname =  ". $row['classname'];
     echo"<br>";
     echo "        coursesecion =  ". $row['coursesection'];
     echo"<br>";
     
    
     echo"<hr>";
            }
       
       
    
        }
        if($checksibling==false){
            echo"this student have no siblings<br>";
        }
    }
    else{
        echo"student not found<br>";
    }
   
       
      mysqli_close($con);
   
  }
  else{
      mysqli_error($con);
  }
 
}


            ?>
            </div>



        </div>
        <div class="signupdesign1">

<div class="signupdesign-data1">
    <h1>
      
    </h1>
   
    <div class="signupclick1">
       
    </div>
</div>
</div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
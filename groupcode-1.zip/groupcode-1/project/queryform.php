<!DOCTYPE html>
<html>

<head>
    <title>
       inserted
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar1">
            <div id="logo1">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars1">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
       
    </nav>

    <div class="midsection">
        <div class="text-pic">
            <div class="textside" style="text-align: center;" >
            <?php

if(isset($_POST['submit'])){
  
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";
    echo"<br>";
    $nam=$_POST['qname'];
    $email=$_POST['qemail'];
    $query=$_POST['textarea'];
    




          
           
              $sql = "insert into query (NAME, email,whatquery )
              VALUES ('$nam','$email','$query')";
              
              if ($con->query($sql) === TRUE) {
                echo "New record created successfully in query form";
              } else {
                echo "Error: " . $sql . "<br>" . $con->error;
              }
              
             
            
$con->close();
    
  }
  else{
    echo "not success";
  }
}


?>

            </div>

        </div>
      

    

    <div class="finalservice">
       
        <br><br>
      
    </div>

    <div class="design2">

        <div class="design-data2">
            <h1>
                if you want to sign up for other child click below button
            </h1>
            <p>
               SIGN up and enter your details.

            </p>

            <div class="click2">
                <button>
                    <a href="signup.html">Sign up</a>
                </button>
            </div>
        </div>
    </div>

    <div class="follow">
        <div class="follow-data">
            <h1>Follow Us On</h1><br>

            <div class="ic">
                <i class="fab fa-twitter"></i>
                <i class="fab fa-youtube"></i>
                <i class="fab fa-snapchat-ghost"></i>
            </div>


        </div>
    </div>
    

</body>

</html>
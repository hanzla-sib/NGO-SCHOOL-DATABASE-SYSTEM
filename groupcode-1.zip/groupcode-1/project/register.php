<html>

<head>
    <title>
        register course
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
                course registration
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
                select the course for registaration.
            </h1>

           
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess";
   $nam=$_POST['naming'];
   $fatcnic=$_POST['rcnic'];
   $registercourse=$_POST['registration'];
    $ageget=NULL;
    $gen=NULL;


$checkregistration=false;
$checkcnic=false;

$sql=" select NAME from student where NAME='$nam' and fcnic='$fatcnic';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
  
   $checkcnic=true;
   
}
date_default_timezone_set("Asia/Karachi");
$date = date('h:i:s');

if($checkcnic==true){
  $sql=" select coursename,age,gender from student where NAME='$nam' and fcnic='$fatcnic';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
  $ageget=$row["age"];
  $gen=$row["gender"];
  if($row["coursename"]=="Math"){
    $checkregistration=true;
  }
  else  if($row["coursename"]=="Science"){
    $checkregistration=true;
  }
  else  if($row["coursename"]=="English"){
    $checkregistration=true;
  }
  else  if($row["coursename"]=="Urdu"){
    $checkregistration=true;
  }
  
   
   
}
if($checkregistration==true){
  $sql=" select coursetime from student where NAME='$nam' and fcnic='$fatcnic';";
  $result1 = mysqli_query($con, $sql);
  $diff=NULL;
  $lasttime=NULL;
while($row=mysqli_fetch_assoc($result1))
{
$diff=$row['coursetime'];
$sql="select SUBTIME(CURTIME(), '$diff') AS Result; ";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
  $ans=$row['Result'];
    
    $sql="select TIME_TO_SEC('$ans') AS Result; ";
  $result1 = mysqli_query($con, $sql);
  while($row=mysqli_fetch_assoc($result1))
{
  $lasttime=$row['Result'];

  //echo"$lasttime";
}

}
}
if($lasttime>10){
  $sql="select coursesection from student where `NAME`='$nam' and `fcnic`='$fatcnic' ";
  $result1 = mysqli_query($con, $sql);
  while($row=mysqli_fetch_assoc($result1))
{
  $lastcoursereg=$row['coursesection'];
echo"$lastcoursereg<br>";
  //echo"$lasttime";
}
$sql="update section set counting=counting-1 where sectionname='$lastcoursereg';";
if ($con->query($sql) === TRUE) {
  echo "section--<br>";
} else {
  echo "Error updating registartion: " . $con->error;
}

  // $sql="update student set coursename='$registercourse' , coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
  // if ($con->query($sql) === TRUE) {
  //   echo "registation updated successfully after completing course in student";
  // } else {
  //   echo "Error updating registartion: " . $con->error;
  // }
  if($ageget>=3 && $ageget<=4){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='math-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }

        $sql="update section set counting=counting+1 where sectionname='math-1-(M)';";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Science-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-1-(M)';";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Urdu-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-1-(M)';";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='English-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-1-(M)';";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='math-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-1-(F)';";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Science-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-1-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Urdu-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-1-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='English-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-1-(F)'";
      }
    }
    
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  else if($ageget>4 && $ageget<=7){
    
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='math-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-2-(M);";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Science-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-2-(M);";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Urdu-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-2-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='English-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        $sql="update section set counting=counting+1 where sectionname='English-2-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='math-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-2-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Science-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-2-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Urdu-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-2-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='English-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-2-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  if($ageget>7 && $ageget<=10){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='math-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-3-(M)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Science-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-3-(M)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Urdu-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-3-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='English-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-3-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='math-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-3-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Science-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-3-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Urdu-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-3-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='English-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-3-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  if($ageget>10 && $ageget<=13){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='math-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-4-(M)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Science-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname=''Science-4-(M)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Urdu-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-4-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='English-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-4-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='math-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-4-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Science-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-4-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Urdu-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-4-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='English-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-4-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  if($ageget>13 && $ageget<=15){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='math-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-5-(M)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Science-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-5-(M)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Urdu-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-5-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='English-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-5-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='math-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-5-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Science-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-5-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Urdu-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-5-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='English-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-5-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
     

    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  $sql="update student set fee='unpaid' where `NAME`='$nam' and `fcnic`='$fatcnic'";
      if ($con->query($sql) === TRUE) {
        echo "fee status updated successfully in student";
        $ran=(rand(10000,100000));
        echo "fee status updated successfully in student";
        $sql="update student set chalan='$ran' where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "chalan generated successfully in student";
        }
        else{
          echo "chalan not generated  in student";
        }
       
      } else {
        echo "Error updating fee registartion: " . $con->error;
      }


}
else{
  $sql=" select NAME ,coursename from student where NAME='$nam' and fcnic='$fatcnic';";
  $result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
  echo "--student name = : $nam is already registered  in  = :". $row['coursename'] ;
  
   
}
}


}
else if($checkregistration==false){
  if($ageget>=3 && $ageget<=4){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='math-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-1-(M)';";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Science-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-1-(M)';";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Urdu-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-1-(M)';";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='English-1-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-1-(M)';";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='math-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-1-(F)';";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Science-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-1-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='Urdu-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-1-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='1' ,coursesection='English-1-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-1-(F)'";
      }
    }
    
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  else if($ageget>4 && $ageget<=7){
    
    if($gen=='male'){
      if($registercourse=='Math'){
        echo"math";
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='math-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-2-(M)';";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Science-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-2-(M)';";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Urdu-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-2-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='English-2-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-2-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='math-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-2-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Science-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-2-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='Urdu-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-2-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='2' ,coursesection='English-2-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-2-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  if($ageget>7 && $ageget<=10){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='math-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-3-(M)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Science-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-3-(M)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Urdu-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-3-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='English-3-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-3-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='math-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-3-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Science-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-3-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='Urdu-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-3-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='3' ,coursesection='English-3-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-3-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  if($ageget>10 && $ageget<=13){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='math-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-4-(M)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Science-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname=''Science-4-(M)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Urdu-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-4-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='English-4-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-4-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='math-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-4-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Science-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-4-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='Urdu-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-4-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='4' ,coursesection='English-4-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-4-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  if($ageget>13 && $ageget<=15){
    if($gen=='male'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='math-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-5-(M)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Science-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-5-(M)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Urdu-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-5-(M)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='English-5-(M)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-5-(M)'";
      }
    }
    else if($gen=='female'){
      if($registercourse=='Math'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='math-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='math-5-(F)'";
      }
      else if($registercourse=='Science'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Science-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Science-5-(F)'";
      }
      else if($registercourse=='Urdu'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='Urdu-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='Urdu-5-(F)'";
      }
      else if($registercourse=='English'){
        $sql="update student set coursename='$registercourse',classname='5' ,coursesection='English-5-(F)', coursetime=now() where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "registation updated successfully in student";
        } else {
          echo "Error updating registartion: " . $con->error;
        }
        $sql="update section set counting=counting+1 where sectionname='English-5-(F)'";
      }
    }
    if ($con->query($sql) === TRUE) {
      echo "registation updated successfully in student";
     
    } else {
      echo "Error updating registartion: " . $con->error;
    }
  }
  $sql="update student set fee='unpaid' where `NAME`='$nam' and `fcnic`='$fatcnic'";
      if ($con->query($sql) === TRUE) {
        $ran=(rand(10000,100000));
        echo "fee status updated successfully in student";
        $sql="update student set chalan='$ran' where `NAME`='$nam' and `fcnic`='$fatcnic'";
        if ($con->query($sql) === TRUE) {
          echo "chalan generated successfully in student";
        }
        else{
          echo "chalan not generated  in student";
        }
      } else {
        echo "Error updating fee registartion: " . $con->error;
      }
}
else{
  $sql=" select NAME ,coursename from student where NAME='$nam' and fcnic='$fatcnic';";
  $result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
  echo "student name = : $nam is already registered  in = :". $row['coursename'] ;
  
   
}
  
}
}
else{
  echo"RECORD NOT FOUND AGAINST $nam ";
}
      
      mysqli_close($con);
   
  }
  else{
    echo "not success";
  }
}


            ?>
            </div>



        </div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
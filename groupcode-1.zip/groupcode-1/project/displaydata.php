<html>

<head>
    <title>
       searching
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
                data of student
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
                searching the student
            </h1>

           
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";

   $nam=$_POST['naming'];
   $roll=$_POST['rnumk'];
  
   
    


$checkcnic=false;

$sql="select * from student where Name='$nam' and rollnumber='$roll'";
$result1 = mysqli_query($con, $sql);

while($row=mysqli_fetch_assoc($result1))
{
    
   
   $checkcnic=true;
   
}
if($checkcnic==true){
  $sql=" select NAME,dob,age,gender,fcnic,gcnic,coursename,classname,coursesection,fee,rollnumber from student where NAME='$nam' and rollnumber='$roll';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
    echo "    rollnumber = : ". $row["rollnumber"];
    echo"<br>";
    echo "    name = : ". $row["NAME"];
    echo"<br>";
   echo"      dob ".$row["dob"];
   echo"<br>";
   echo"      age ".$row["age"];
   echo"<br>";
   echo"      gender ".$row["gender"];
   echo"<br>";
   echo"      father cnic ".$row["fcnic"];
   echo"<br>";
   echo"      guardiancnic ".$row["gcnic"];
   echo"<br>";
   echo"      registered course ".$row["coursename"];
   echo"<br>";
   echo"      class ".$row["classname"];
   echo"<br>";
   echo"      coursename ".$row["coursename"];
   echo"<br>";
   echo"      section ".$row["coursesection"];
   echo"<br>";
   echo"      fee status ".$row["fee"];
   echo"<br>";
   
   
}


}
else{
    echo"record not found";
    echo"<br>";
}

      
      mysqli_close($con);
   
  }
  else{
    echo "not success";
  }
}


            ?>
            </div>



        </div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
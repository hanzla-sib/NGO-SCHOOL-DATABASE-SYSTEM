<html>

<head>
    <title>
        student acompyning form
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>Hamaray bachay</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
                student acomponing form
            </h1>
        </div>
    </nav>
	
	<div class="signinform">
        <div class="signupheading">
            <h1>
                Enter your Details
            </h1>
        </div>

        <div class="signinformdata">

            <form  method= "post">
				
                <h3>roll number</h3>
                <input type="text" id="roll" name="rollnumber" placeholder="190515" size="7">
				<br>
				<br>
				<br>
                <h3>why parents are absent </h3>
                <input type="text" id="ebsence" name="absence" size="40">
                <br>
				<br>
                <br>
                <br>
                <button type="submit" name="submit" > Submit</button>
            </form>
            

        </div>
    </div>
    <div class="midsection">
        <div class="text-pic">
            <div class="textside" style="text-align: center;" >
            <?php

if(isset($_POST['submit'])){
  
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";
    echo"<br>";
    $checkroll=false;
    $roll=$_POST['rollnumber'];
    $absent=$_POST['absence'];
    $sql = "select rollnumber from student where rollnumber='$roll'";
    $result = mysqli_query($con, $sql);
      while($row=mysqli_fetch_assoc($result))
      {
        $checkroll=true;
      }
      if($checkroll==true){
        $sql = "select rollnumber,NAME,classname,coursesection,gcnic,fcnic from student where rollnumber='$roll'";
        $result = mysqli_query($con, $sql);
        $nam=NULL;
        $classn=NULL;
        $csection=NULL;
        $guardcnic=NULL;
        $fcnic=NULL;
        

          while($row=mysqli_fetch_assoc($result))
          {
            $nam=$row['NAME'];
            $classn=$row['classname'];
            $csection=$row['coursesection'];
            $guardcnic=$row['gcnic'];
            $fcnic=$row['fcnic'];
            echo"$guardcnic";
            
          }
          $sql = "select guardianname from guardian where guardiancnic='$guardcnic'";
          $guardname=NULL;
          $result = mysqli_query($con, $sql);
          while($row=mysqli_fetch_assoc($result))
          {
              echo"hello";
            $guardname=$row['guardianname'];
           
            
          }
          $sql = "insert into parentabsenceform (rollnum, studentname,class,section,guardiananme,fathercnic,justification)
                  VALUES ('$roll','$nam','$classn','$csection','$guardname','$fcnic','$absent')";
                  
                  if ($con->query($sql) === TRUE) {
                    echo "New record created successfully in student";
                  } else {
                    echo "Error: " . $sql . "<br>" . $con->error;
                  }
      }
      else{
          echo"roll number not found";
      }
           
$con->close();
    
  }
  else{
    echo "not success";
  }
}


?>

            </div>

        </div>
      

    
    
    <div class="signindesign1">

        <div class="signindesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMRAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signinclick1">
                <button>
					     <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
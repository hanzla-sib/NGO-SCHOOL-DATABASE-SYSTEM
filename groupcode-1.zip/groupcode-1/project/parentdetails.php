<html>

<head>
    <title>
      parent info
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
               
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
            parents deatils
            </h1>
            <form method="post">
            
                <h3>father cnic</h3>
                <input type="text" id="name" name="cnic" placeholder="5440067694737" size="40">
                <br>
                <button type="submit" name="submit" > Submit</button>
                <br>
                <hr><br><br><br>



            </form>
           
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";
    
    $cnic=$_POST['cnic'];
    $checkbool=false;
    $sql=" select fathercnic,fathername from parents where fathercnic='$cnic';";
    $result1 = mysqli_query($con, $sql);
    while($row=mysqli_fetch_assoc($result1))
    {      
        $checkbool=true;
        echo"<b>parent details</b>";
        echo"<br>";
       
        
        $fathercnic=$row['fathercnic'];
      

         echo "       fathername =  ". $row['fathername'];
         echo"<br>";
        echo "       fathercnic =  ". $row['fathercnic'];
        echo"<br>";
       
      
       echo"<hr>";
    }
    if($checkbool==true){
        echo"<b>child details</b><br>";
        $i=0;
        $sql=" select NAME,rollnumber,gcnic,coursename,classname,coursesection from student where fcnic='$cnic';";
        $result1 = mysqli_query($con, $sql);
        $guardiancnic = array();
        while($row=mysqli_fetch_assoc($result1))
        {
           
            // echo "       sectionname =  ". $row["sectionname"];
            // echo "   | |     total students =  ". $row["counting"];
          $guardiancnic[$i]=$row['gcnic'];
          $i++;
        echo"<b>child $i details</b>";
        echo"<br>";
        echo "       NAME =  ". $row['NAME'];
        echo"<br>";
        echo "       rollnumber =  ". $row['rollnumber'];
        echo"<br>";
        echo "       coursename =  ". $row['coursename'];
        echo"<br>";
        echo "        classname =  ". $row['classname'];
        echo"<br>";
        echo "       coursesection =  ". $row['coursesection'];
        echo"<br>";
    
        echo"<br>";
        echo"<hr>";
    
        }
       
        echo"<b>guardian details</b><br>";
        $p=0;
        $length = count($guardiancnic);
        for ($j = 0; $j < $length; $j++) {
            $sql=" select guardianname,guardiancnic,guardianreletion,guardianaddress,guardianphone from guardian where guardiancnic='$guardiancnic[$j]';";
            $p++;
            $result1 = mysqli_query($con, $sql);
        while($row=mysqli_fetch_assoc($result1))
        { 
            // echo "       sectionname =  ". $row["sectionname"];
            // echo "   | |     total students =  ". $row["counting"];
          
            
        //    echo"<hr>";
        echo"<b>guardian $p details</b>";
        echo"<br>";
        echo "       guardianname =  ". $row['guardianname'];
        echo"<br>";
        echo "      guardiancnic =  ". $row['guardiancnic'];
        echo"<br>";
        echo "       guardianreletion =  ". $row['guardianreletion'];
        echo"<br>";
        echo "        guardianaddress =  ". $row['guardianaddress'];
        echo"<br>";
        echo "        guardianphone =  ". $row['guardianphone'];
        echo"<br>";
       
        echo"<hr>";
    
        }
    }
    


    }
    else{
        echo"parent  not found <br>";
    }


   

    

      mysqli_close($con);
   
  }
  else{
      mysqli_error($con);
  }
 
}


            ?>
            </div>



        </div>
        <div class="signupdesign1">

<div class="signupdesign-data1">
    <h1>
      
    </h1>
   
    <div class="signupclick1">
       
    </div>
</div>
</div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
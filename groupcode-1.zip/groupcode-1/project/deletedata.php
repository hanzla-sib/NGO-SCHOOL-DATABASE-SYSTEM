<html>

<head>
    <title>
       deleting data
    </title>
    <link rel="stylesheet" href="css/inf.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/7f6d91d128.js" crossorigin="anonymous"></script>
</head>

<body>
    <nav>
        <div class="navbar3">
            <div id="logo3">
                <h1>HAMARAY BACHAY</h1>
            </div>
            <div id="bars3">
                <a href="intro.html">Home</a>
				<a href="signin.html">SignIn</a>
                <a href="signup.html">SignUp</a>
                <a href="contactus.html">Contact</a>
				 <a href="info.html">About</a>
            </div>


        </div>
        <div id="abttext3">
            <h1>
            
            </h1>
        </div>
    </nav>
	
	<div class="signupform">
        <div class="signupheading">
            <h1>
                deleting the student
            </h1>

           
            </div>
   



        </div>

       
            <?php

if(isset($_POST['submit'])){
  $con = mysqli_connect("localhost","root","","hamaraybachay");

  if($con){
    echo "sucess<br>";

   $nam=$_POST['naming'];
   $fatcnic=$_POST['rcnic'];
   
    


$checkcnic=false;
$count=0;
$countguard=0;
$sql=" select gcnic from student where NAME='$nam' and fcnic='$fatcnic';";
$guardiancnic=NULL;
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
    $guardiancnic=$row['gcnic'];
   $checkcnic=true;
   
}
$sql=" select NAME from student where  fcnic='$fatcnic';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
  $count++;
   
}
$sql=" select NAME from student where  gcnic='$guardiancnic';";
$result1 = mysqli_query($con, $sql);
while($row=mysqli_fetch_assoc($result1))
{
  $countguard++;
   
}
if($checkcnic==true){
    $sql = "select coursesection from student WHERE NAME='$nam' and fcnic='$fatcnic';";
    $result1 = mysqli_query($con, $sql);
    $row=mysqli_fetch_assoc($result1);
    if($row['coursesection']!=NULL){
      $savesection=$row['coursesection'];
      $sql = "delete from student WHERE NAME='$nam' and fcnic='$fatcnic';";

      if ($con->query($sql) === TRUE) {
        echo "Record deleted successfully";
      } else {
        echo "Error deleting record: " . $con->error;
      }
      $sql="update section set counting=counting-1 where sectionname='$savesection';";
      if ($con->query($sql) === TRUE) {
        echo "Record deleted successfully";
      } else {
        echo "Error deleting record: " . $con->error;
      }
    }
    else{
      $sql = "delete from student WHERE NAME='$nam' and fcnic='$fatcnic';";

      if ($con->query($sql) === TRUE) {
        echo "Record deleted successfully";
      } else {
        echo "Error deleting record: " . $con->error;
      }
    }

   

    if($count<=1){
        $sql = "delete from parents WHERE fathercnic='$fatcnic';";

        if ($con->query($sql) === TRUE) {
          echo "Record deleted successfully from parent";
        } else {
          echo "Error deleting record in parent: " . $con->error;
        }
    }
    if($countguard<=1){
        $sql = "delete from guardian WHERE guardiancnic='$guardiancnic';";

        if ($con->query($sql) === TRUE) {
          echo "Record deleted successfully from guardian";
        } else {
          echo "Error deleting record in guardian: " . $con->error;
        }
    }


}
else{
    echo"record not found";
    echo"<br>";
}

      
      mysqli_close($con);
   
  }
  else{
    echo "not success";
  }
}


            ?>
            </div>



        </div>
    </div>

    <div class="signupdesign1">

        <div class="signupdesign-data1">
            <h1>
               Feel Free to Contact
            </h1>
            <p>
                If you are having a Problem? Contact Any time to HAMARAY BACHAY(NGO).
				Our team will respond you soon on your email.
            </p>

            <div class="signupclick1">
                <button>
					         <a href="contactus.html">TAKE ME TO CONTACT PAGE</a>
                </button>
            </div>
        </div>
    </div>
</body>

</html>
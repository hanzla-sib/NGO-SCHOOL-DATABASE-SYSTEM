DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `assignednewclass`(IN `time` TIME, IN `time2` INT)
BEGIN
select * from student where coursetime BETWEEN time and time2; END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `classchangehistory`(IN `roll` INT)
BEGIN
select * from historyofclass where roll=rollnumber;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `listofguardians`()
BEGIN select g.guardianname,g.guardianreletion, s.rollnumber,s.NAME from guardian g join student s ON g.guardiancnic=s.gcnic ORDER by guardianreletion ; END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `listofmotherwithspouses`()
BEGIN select fathername,fathercnic,mothername,mothercnic from parents; END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `listofparentswithchild`()
BEGIN select s.rollnumber,s.NAME,p.fathername,p.fathercnic from parents p join student s on p.fathercnic=s.fcnic; END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `listofstudents`()
BEGIN select * from student; END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `newparents`(IN `time1` TIME, IN `time2` TIME)
BEGIN
select p.fathername,p.fathercnic,p.mothername,s.rollnumber,s.Name from parents p join student s on p.fathercnic=s.fcnic where s.coursetime BETWEEN time1 and time2;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `newstudentsgroupbyclass`(IN `time` TIME, IN `time2` TIME)
BEGIN select * from student where coursetime BETWEEN time and time2 ORDER BY classname; END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `parentsofearlyintroducers`()
BEGIN select fathername,mothername,fathercnic,mothercnic from parents p join student s on p.fathercnic=s.fcnic where s.age<=4; END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `studentwithsiblings`()
BEGIN select s.NAME,s.rollnumber,t.NAME as 'sibling name',t.rollnumber as 'sibling rollnumber', t.classname from student s join student t on s.fcnic=t.fcnic where s.rollnumber<>t.rollnumber order BY t.classname; END$$
DELIMITER ;


-- student table
CREATE TABLE student(   
    id INT AUTO_INCREMENT NOT NULL,
    NAME VARCHAR(40) NOT NULL,
    dob DATE NOT NULL,
    age float NOT null,
    gender VARCHAR(10) NOT NULL,
    CONSTRAINT PRIMARY KEY(id)
);

-- #parent table
CREATE TABLE parents(
    fathername VARCHAR(40) NOT NULL,
    fathercnic VARCHAR(20) NOT NULL,
    mothername VARCHAR(40) NOT NULL,
    mothercnic VARCHAR(20) NOT NULL,
    fathernumber VARCHAR(15) NOT NULL,
    mothernumber VARCHAR(15) NOT NULL,
    address varchar(100) not null,
    CONSTRAINT PRIMARY KEY(fathercnic)
);

CREATE TABLE guardian(
    guardianreletion VARCHAR(40) NOT NULL,
    guardianname VARCHAR(40) NOT NULL,
    guardiancnic VARCHAR(20) NOT NULL,
    guardianaddress VARCHAR(100) NOT NULL,
    guardianphone VARCHAR(20) NOT NULL,
    CONSTRAINT PRIMARY KEY(guardiancnic)
);

ALTER TABLE
    student ADD fcnic VARCHAR(20) NOT NULL,
    ADD CONSTRAINT FOREIGN KEY(fcnic) REFERENCES parents(fathercnic),
    ADD gcnic VARCHAR(20) NOT NULL,
    ADD CONSTRAINT FOREIGN KEY(gcnic) REFERENCES guardian(guardiancnic);


CREATE TABLE QUERY(
    id INT AUTO_INCREMENT,
    NAME VARCHAR(20),
    email VARCHAR(20),
    whatquery VARCHAR(300),
    PRIMARY KEY(id)
);

CREATE TABLE courses(
    id INT AUTO_INCREMENT,
    coursename VARCHAR(10),
    PRIMARY KEY(id)
);

insert into courses (`coursename`) VALUES ("Math");
insert into courses (`coursename`) VALUES ("English");
insert into courses (`coursename`) VALUES ("Urdu");
insert into courses (`coursename`) VALUES ("Science");

ALTER TABLE student 
add coursename varchar(10),
add CONSTRAINT FOREIGN key(coursename) REFERENCES courses(coursename),
add coursetime TIME;



CREATE TABLE admin(
    id INT AUTO_INCREMENT,
    NAME VARCHAR(7) NOT NULL,
    PASS VARCHAR(7) NOT NULL,
    CONSTRAINT PRIMARY KEY(id)
);

INSERT INTO admin(`NAME`,`PASS` )
VALUES('admin', '1234');


CREATE TABLE Class(
    classnumber VARCHAR(2),
    PRIMARY KEY(classnumber)
);
insert into class values(1);
insert into class values(2);
insert into class values(3);
insert into class values(4);
insert into class values(5);


ALTER table student
add classname varchar(2),
add CONSTRAINT FOREIGN key(classname) REFERENCES class(classnumber);


CREATE TABLE section(
    sectionname VARCHAR(20),
    counting int,
    CONSTRAINT PRIMARY KEY(sectionname)
);


insert into section(sectionname) values('math-1-(M)');
insert into section(sectionname) values('math-1-(F)');
insert into section(sectionname) values('math-2-(M)');
insert into section(sectionname) values('math-2-(F)');
insert into section(sectionname) values('math-3-(M)');
insert into section(sectionname) values('math-3-(F)');
insert into section(sectionname) values('math-4-(M)');
insert into section(sectionname) values('math-4-(F)');
insert into section(sectionname) values('math-5-(M)');
insert into section(sectionname) values('math-5-(F)');
insert into section(sectionname) values('English-1-(M)');
insert into section(sectionname) values('English-1-(F)');
insert into section(sectionname) values('English-2-(M)');
insert into section(sectionname) values('English-2-(F)');
insert into section(sectionname) values('English-3-(M)');
insert into section(sectionname) values('English-3-(F)');
insert into section(sectionname) values('English-4-(M)');
insert into section(sectionname) values('English-4-(F)');
insert into section(sectionname) values('English-5-(M)');
insert into section(sectionname) values('English-5-(F)');
insert into section(sectionname) values('Science-1-(M)');
insert into section(sectionname) values('Science-1-(F)');
insert into section(sectionname) values('Science-2-(M)');
insert into section(sectionname) values('Science-2-(F)');
insert into section(sectionname) values('Science-3-(M)');
insert into section(sectionname) values('Science-3-(F)');
insert into section(sectionname) values('Science-4-(M)');
insert into section(sectionname) values('Science-4-(F)');
insert into section(sectionname) values('Science-5-(M)');
insert into section(sectionname) values('Science-5-(F)');
insert into section(sectionname) values('Urdu-1-(M)');
insert into section(sectionname) values('Urdu-1-(F)');
insert into section(sectionname) values('Urdu-2-(M)');
insert into section(sectionname) values('Urdu-2-(F)');
insert into section(sectionname) values('Urdu-3-(M)');
insert into section(sectionname) values('Urdu-3-(F)');
insert into section(sectionname) values('Urdu-4-(M)');
insert into section(sectionname) values('Urdu-4-(F)');
insert into section(sectionname) values('Urdu-5-(M)');
insert into section(sectionname) values('Urdu-5-(F)');

ALTER table student
add coursesection varchar(20),
add CONSTRAINT FOREIGN key(coursesection) REFERENCES section(sectionname);

ALTER TABLE parents 
add job varchar(20);

ALTER table class
add fee int(5);

UPDATE class
set `fee`=2000 where `classnumber`='1';

UPDATE class
set `fee`=4000 where `classnumber`='2';

UPDATE class
set `fee`=6000 where `classnumber`='3';

UPDATE class
set `fee`=8000 where `classnumber`='4';

UPDATE class
set `fee`=10000 where `classnumber`='5';

update section
set counting=0;

ALTER TABLE student add fee varchar(10) null;
ALTER table student
add chalan int UNIQUE;

ALTER table parents
add anyemergency varchar(10) NULL;

ALTER table student
ADD rollnumber int UNIQUE;

CREATE TABLE parentabsenceform(
    id INT AUTO_INCREMENT,
    rollnum INT,
    studentname VARCHAR(40),
    class VARCHAR(20),
    section VARCHAR(40),
    guardiananme VARCHAR(30),
    fathercnic VARCHAR(20),
    justification VARCHAR(40),
    CONSTRAINT PRIMARY KEY(id),
    CONSTRAINT FOREIGN KEY(rollnum) REFERENCES student(rollnumber)
);

CREATE TABLE historyofclass(
    rollnumber INT,
    oldclassname VARCHAR(30),
    newclassname VARCHAR(30),
    reasonforchange VARCHAR(40),
    approvedby varchar(30)
    
);
insert into student (`NAME`,`dob`,`age`,`gender`,`fcnic`,`gcnic`,`coursename`,`coursetime`,`classname`,`coursesection`,`fee`,`chalan`,`rollnumber`) values("Waqas Ahmad",STR_TO_DATE('02-01-2015', '%m-%d-%Y'),6.9,"male","123456","654321","English",now(),2,"English-2-(M)","paid",12345,198536);
insert into student (`NAME`,`dob`,`age`,`gender`,`fcnic`,`gcnic`,`coursename`,`coursetime`,`classname`,`coursesection`,`fee`,`chalan`,`rollnumber`) values("Hanzla sibghat",STR_TO_DATE('02-01-2016', '%m-%d-%Y'),5.9,"male","123456","123091","Science",now(),2,"Science-2-(M)","paid",23456,176543);
insert into student (`NAME`,`dob`,`age`,`gender`,`fcnic`,`gcnic`,`coursename`,`coursetime`,`classname`,`coursesection`,`fee`,`chalan`,`rollnumber`) values("maaz ali",STR_TO_DATE('03-08-2015', '%m-%d-%Y'),6.3,"male","123456","836252","English",now(),2,"English-2-(M)","unpaid",34567,109865);
insert into student (`NAME`,`dob`,`age`,`gender`,`fcnic`,`gcnic`,`coursename`,`coursetime`,`classname`,`coursesection`,`fee`,`chalan`,`rollnumber`) values("ali ahmad",STR_TO_DATE('09-01-2016', '%m-%d-%Y'),5.3,"male","545677","816383","Math",now(),2,"Math-2-(M)","unpaid",45678,725634);
insert into student (`NAME`,`dob`,`age`,`gender`,`fcnic`,`gcnic`,`coursename`,`coursetime`,`classname`,`coursesection`,`fee`,`chalan`,`rollnumber`) values("ahmad asad",STR_TO_DATE('03-12-2017', '%m-%d-%Y'),4.0,"male","335864","826140","Urdu",now(),1,"Urdu-1-(M)","paid",56789,198632);


insert into parents (`fathername`,`fathercnic`,`mothername`,`mothercnic`,`fathernumber`,`mothernumber`,`address`,`job`,`anyemergency`)VALUES ("Ahmad","123456","azka","876549","1211231123","81276533","sahiwal","doctor","none");
insert into parents (`fathername`,`fathercnic`,`mothername`,`mothercnic`,`fathernumber`,`mothernumber`,`address`,`job`,`anyemergency`)VALUES ("Asad","545677","khalida","765109","98373733","12637321","lahore","engineer","none");
insert into parents (`fathername`,`fathercnic`,`mothername`,`mothercnic`,`fathernumber`,`mothernumber`,`address`,`job`,`anyemergency`)VALUES ("Ali","335864","arooj","102745","897827663","12737489","sialkot","NGO","none");


insert into guardian(`guardianreletion`,`guardianname`,`guardiancnic`,`guardianaddress`,`guardianphone`)
values("aunt","abc","654321","hno3","12346842");

insert into guardian(`guardianreletion`,`guardianname`,`guardiancnic`,`guardianaddress`,`guardianphone`)
values("aunt","ahf","123091","hno4","23564224");

insert into guardian(`guardianreletion`,`guardianname`,`guardiancnic`,`guardianaddress`,`guardianphone`)
values("cousin","ajad","836252","hno5","56785322");

insert into guardian(`guardianreletion`,`guardianname`,`guardiancnic`,`guardianaddress`,`guardianphone`)
values("uncle","akdf","816383","hno7","35647876");

update section
set `counting`=counting+1 where `sectionname`="Math-2-(M)";

update section
set `counting`=counting+1 where `sectionname`="Math-2-(M)";


update section
set `counting`=counting+1 where `sectionname`="English-2-(M)";

update section
set `counting`=counting+1 where `sectionname`="Urdu-1-(M)";

update section
set `counting`=counting+1 where `sectionname`="Science-2-(M)";

insert into query (NAME,email,whatquery) values("Hanzla sibghat","hanzlasib@gmail.com","How to apply?");
insert into parentabsenceform (rollnum, studentname,class,section,guardiananme,fathercnic,justification) VALUES ('198536
','Waqas Ahmad','2','English-2-(M)','abc','123456','busy');

insert into historyofclass(rollnumber,oldclassname,newclassname,reasonforchange,approvedby) values('198536'
,2,1,'dull in studies','principle');
create table historyofparent(
fathername varchar(40),
    fathercnic varchar(20),
    mothername varchar(40),
    mothercnic varchar(20),
    fathernumber varchar(15),
    mothernumber varchar(15),
    address	varchar(100),
    job	varchar(20),
    anyemergency varchar(10)
    
);
CREATE TRIGGER `saveparentdata` BEFORE UPDATE ON `parents` FOR EACH ROW insert into historyofparent values(OLD.fathername,OLD.fathercnic,OLD.mothername,OLD.mothercnic,OLD.fathernumber,OLD.mothernumber,OLD.address,OLD.job,OLD.anyemergency);
-- commit();